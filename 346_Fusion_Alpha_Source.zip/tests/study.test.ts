import { describe,it,expect } from 'vitest'
import { content } from '../src/content'
import { defaultPersisted } from '../src/state/defaults'
import { installBuiltInTextbooks } from '../src/general/textbook'
import { defaultFusion, allCandidates, beginTask, finishTask, lockChapters, decide, remaining, rollDay, preparePractice, beginPractice } from '../src/fusion/planner'
import { validatePlatform, makeEnvelope, inspectFusionImport } from '../src/fusion/transfer'
import { defaultConfig, newStudy, netBudget, daysLeft, DAY, makeSession, saveScoped, shortGapDays, coverage, matchingRecords, key, estimate, studyDate } from '../src/study/coach'
import { tickStudy, confirmTime, tickExam, confirmExamTime } from '../src/study/time'
import type { FusionState } from '../src/fusion/types'
const now=Date.parse('2026-10-29T10:00:00+08:00'),mrc=()=>defaultPersisted()
function platform(minutes=180){let s=defaultFusion(now);s.general=installBuiltInTextbooks(s.general,now);s.study=newStudy({...defaultConfig,inputMinutes:minutes});s.day.budgetMinutes=netBudget(s.study.config);s.day.date=studyDate(now);return lockChapters(s,mrc(),now)}
function tested(s:FusionState,activity:'short'|'full'='short',time=now){const p=s.general.points.find(p=>!p.trainingBlocked)!;s.study!.declarations[key('general',p.id)]=time-2*DAY;const c={...allCandidates(s,mrc(),time).find(c=>c.itemId===p.id)!,activity};return beginTask(s,c,time)}
function finish(s:FusionState,time=now+1000,outcome:'pass'|'miss'|'untested'='pass'){
 const session=s.study!.session!;s.study!.session={...session,phase:'compare',draft:'原始闭卷解释',frozenDraft:'原始闭卷解释',written:true,structure:true,outcomes:Object.fromEntries(session.scope.map(p=>[p.id,outcome]))}
 const record=saveScoped(s,mrc(),time)!;return finishTask({...s,study:{...s.study!,records:[...s.study!.records,record],session:record}},record.id,time)
}
describe('evidence coach scope and compatibility',()=>{
 it('uses dynamic Beijing exam days and unambiguous protected budgets',()=>{expect(daysLeft(defaultConfig,now)).toBe(51);expect(daysLeft(defaultConfig,now+DAY)).toBe(50);expect(netBudget({...defaultConfig,budgetKind:'total',inputMinutes:180})).toBe(81);expect(netBudget({...defaultConfig,inputMinutes:180})).toBe(162);expect(netBudget({...defaultConfig,budgetKind:'total',inputMinutes:60})).toBe(0)})
 it('keeps155 main items, separates14supplements, excludes22references and old editions',()=>{const s=platform();const rows=coverage(s,mrc(),now);expect(rows.map(r=>r.total)).toEqual([56,59,40]);expect(rows.reduce((n,r)=>n+r.uncovered,0)).toBe(155)})
 it('declaration means learned pending verification, not a grade',()=>{const s=platform();s.study!.declarations[key('general',s.general.points[0].id)]=now;expect(coverage(s,mrc(),now).find(r=>r.subject==='运动生理学')!.declared).toBe(1);expect(s.general.logs).toHaveLength(0);expect(s.general.points[0].totalReviews).toBe(0)})
 it('freezes scope across JSON backup and reload without creating old engine evidence',()=>{const s=tested(platform());const before=JSON.stringify(s.general);const restored=inspectFusionImport(JSON.stringify(makeEnvelope(s,mrc())),platform(),mrc()).platform;expect(restored.study!.session).toEqual(s.study!.session);expect(JSON.stringify(restored.general)).toBe(before);expect(s.study!.session!.scope.length).toBeLessThanOrEqual(3)})
 it('unselected points have no outcome; untested stays distinct from miss',()=>{const s=finish(tested(platform()),now+1000,'untested');const r=s.study!.records[0];expect(Object.values(r.outcomes).every(v=>v==='untested')).toBe(true);expect(r.complete).toBe(false);expect(Object.keys(r.outcomes)).toEqual(r.scope.map(p=>p.id));expect(s.general.logs).toHaveLength(0);expect(mrc().attempts).toHaveLength(0)})
 it('short successes never become whole-question verification or FSRS scores',()=>{const s=finish(tested(platform()));expect(s.study!.records[0].complete).toBe(false);expect(s.general.points[0].totalReviews).toBe(0);expect(coverage(s,mrc(),now).every(r=>r.verified===0)).toBe(true)})
 it('full delayed test requires every point, structure, writing and no hints',()=>{const s=tested(platform(),'full');const good=finish(structuredClone(s));expect(good.study!.records[0].complete).toBe(true);for(const flag of ['hinted','structure','written'] as const){const copy=structuredClone(s),session=copy.study!.session!;copy.study!.session={...session,phase:'compare',frozenDraft:'a',outcomes:Object.fromEntries(session.scope.map(p=>[p.id,'pass'])),structure:true,written:true,[flag]:flag==='hinted'};expect(saveScoped(copy,mrc(),now+1000)!.complete).toBe(false)}})
 it('same day repairs cannot count as delayed full passes',()=>{let s=finish(tested(platform(),'full'),now+1000,'miss');const task={...s.active!,id:'retry',startedAt:now+3600000,status:'in_progress' as const};s={...s,active:task,day:{...s.day,tasks:[...s.day.tasks,task]},study:{...s.study!,session:makeSession(s,task)}};s=finish(s,now+3601000);expect(s.study!.records.at(-1)!.delayed).toBe(false);expect(s.study!.records.at(-1)!.complete).toBe(false)})
 it('duplicate submission is idempotent and successful tasks are not immediately repeated',()=>{const s=finish(tested(platform()));expect(saveScoped(s,mrc(),now+2000)).toBeNull();expect(allCandidates(s,mrc(),now+2000).some(c=>c.itemId===s.active!.itemId)).toBe(false)})
 it('rotates normally tested points while including missed and sports points',()=>{let s=finish(tested(platform()));const task={...s.active!,id:'rotate',activity:'short' as const,startedAt:now+DAY};const second=makeSession(s,task);if(second.allPointIds.length>3) expect(second.scope.map(p=>p.id)).not.toEqual(s.study!.session!.scope.map(p=>p.id))})
 it('changed source cannot inherit prior scope evidence',()=>{const s=finish(tested(platform(),'full'));expect(matchingRecords(s,'general',s.active!.itemId)).toHaveLength(1);s.general={...s.general,points:s.general.points.map(p=>p.id===s.active!.itemId?{...p,content:p.content+'\n新增原文'}:p)};expect(matchingRecords(s,'general',s.active!.itemId)).toHaveLength(0)})
 it('rejects unknown extension versions without empty defaults',()=>{const s=platform();(s.study as any).version=99;expect(()=>validatePlatform(s)).toThrow('教练扩展')})
 it('old backup and old in-flight recall remain readable',()=>{const old=defaultFusion(now);expect(validatePlatform(old).study).toBeUndefined();expect(inspectFusionImport(JSON.stringify(makeEnvelope(old,mrc())),platform(),mrc()).platform.study).toBeUndefined()})
 it('zero and tiny budgets stop without enlargement',()=>{for(const minutes of [0,1,5,10]){const s=platform(minutes),d=decide(s,mrc(),now);expect(d.kind).toBe('done');expect(s.day.budgetMinutes).toBe(netBudget(s.study!.config))}})
 it('new coverage survives overdue backlog but is bounded',()=>{const s=platform(180);for(const p of s.general.points){p.totalReviews=2;p.lastReviewedAt=now-3*DAY;p.dueDate=now-DAY}s.day.selectedChapters={};const ready=lockChapters(s,mrc(),now),d=decide(ready,mrc(),now);expect(d.kind).toBe('next');if(d.kind==='next')expect(d.candidate.isNew).toBe(true)})
 it('manual practice cannot enlarge the budget',()=>{const s=platform(5),id=content.items.find(i=>i.coreA)!.id,scope={module:'mrc' as const,kind:'item' as const,title:'manual',itemIds:[id]};expect(preparePractice(s,mrc(),scope,now).extraMinutes).toBeGreaterThan(0);expect(beginPractice(s,mrc(),scope,now)).toBe(s)})
 it('retry cooldown and daily maximum bound failed work',()=>{let s=finish(tested(platform()),now+1000,'miss');const id=s.active!.itemId;expect(allCandidates(s,mrc(),now+2000).some(c=>c.itemId===id)).toBe(false);const later=now+3600000,c=allCandidates(s,mrc(),later).find(c=>c.itemId===id)!;expect(c).toBeTruthy();s=finish(beginTask(s,c,later),later+1000,'miss');expect(allCandidates(s,mrc(),later+3600000).some(c=>c.itemId===id)).toBe(false)})
 it('timing ignores long suspended intervals and pause, preserves net seconds across midnight',()=>{let s=tested(platform());s=tickStudy(s,now,true);s=tickStudy(s,now+10000,true);s=tickStudy(s,now+300000,true);expect(s.study!.time[s.active!.id].seconds).toBe(10);s=tickStudy(s,now+310000,false);s=tickStudy(s,now+320000,false);expect(s.study!.time[s.active!.id].seconds).toBe(20);const midnight=Date.parse('2026-10-30T00:00:00+08:00');s=tickStudy(s,midnight-5000,true);s=rollDay(s,midnight+5000);s=tickStudy(s,midnight+5000,true);expect(s.study!.time[s.active!.id].seconds).toBe(30);expect(s.day.date).toBe('2026-10-30');expect(s.study!.time[s.active!.id].days['2026-10-30']).toBe(5)})
 it('net time correction charges overruns and only confirmed samples calibrate',()=>{let s=tickStudy(tested(platform()),now,true);s=finish(s);s=confirmTime(s,200,now+1000);expect(remaining(s)).toBe(0);expect(s.study!.time[s.active!.id].confirmed).toBe(true);expect(estimate(s,s.active!.subject,'short',12)).toBe(12)})
 it('fresh scope checkpoints cannot be implicitly answered by a heading',()=>{const s=tested(platform(),'full');expect(Object.values(s.study!.session!.outcomes).every(v=>v==='untested')).toBe(true);expect(s.study!.session!.structure).toBe(false)})
 it('rejects inconsistent scoped active/session backups',()=>{const s=tested(platform());s.study!.session!.taskId='other';expect(()=>validatePlatform(s)).toThrow('当前任务')})
 it('keeps shared sources once while each completed record retains its scope IDs',()=>{const s=finish(tested(platform()));expect(Object.keys(s.study!.sources!)).toHaveLength(1);expect(s.study!.records[0].scope.every(p=>p.reference==='')).toBe(true);expect(Object.values(s.study!.sources!)[0].some(p=>p.reference.length>0)).toBe(true)})
 it('exam budget and active clock pause independently from original countdown',()=>{let s=platform();s.study!.exams=[{id:'exam',startedAt:now,reserved:15,charges:{[studyDate(now)]:15},snapshot:{answers:{}}}];s.day.examMinutes=15;s=tickExam(s,'exam',now,true);s=tickExam(s,'exam',now+10000,false);s=tickExam(s,'exam',now+DAY,false);expect(s.study!.time.exam.seconds).toBe(10);expect(s.study!.exams[0].snapshot).toEqual({answers:{}});s.study!.exams[0].finishedAt=now+DAY;const before=s.day.examMinutes;s=confirmExamTime(s,'exam',30,now+DAY);expect(s.study!.time.exam.seconds).toBe(1800);expect(s.day.examMinutes).toBeGreaterThan(before!)})
 it('source-less evidence and fabricated complete flags fail validation',()=>{const s=finish(tested(platform()));s.study!.sources={};expect(()=>validatePlatform(s)).toThrow('教练扩展');const full=finish(tested(platform()));full.study!.records[0].complete=true;expect(()=>validatePlatform(full)).toThrow('教练扩展')})
 it('task import rejects unknown activity modes',()=>{const s=tested(platform());(s.active as any).activity='unknown';expect(()=>validatePlatform(s)).toThrow('训练任务')})

 it('coverage lag prevents permanently starving the overview subject',()=>{const s=platform();for(const p of s.general.points.filter(p=>p.subject==='运动生理学'))s.study!.declarations[key('general',p.id)]=now;for(const i of content.items.filter(i=>i.coreA))s.study!.declarations[key('mrc',i.id)]=now;const d=decide(s,mrc(),now);expect(d.kind).toBe('next');if(d.kind==='next')expect(d.candidate.subject).toBe('体育概论')})

 it('supplements have a separate one-new-item quota, never consume main new caps',()=>{let s=platform();const supplementary=allCandidates(s,mrc(),now).find(c=>c.supplement)!;expect(supplementary).toBeTruthy();s=finishTask(beginTask(s,supplementary,now),'supplement-sim',now+1000);const count=s.day.tasks.filter(t=>t.isNew&&!t.supplement&&t.subject==='运动生理学').length;expect(count).toBe(0);const second=allCandidates(s,mrc(),now).find(c=>c.supplement&&c.itemId!==supplementary.itemId)!;expect(beginTask(s,second,now+2000)).toBe(s);expect(coverage(s,mrc(),now).find(r=>r.subject==='运动生理学')!.total).toBe(59)})

 it('pausing new learning also pauses new supplements while keeping reviews eligible',()=>{const s=platform();s.settings.subjects['运动生理学'].newCap=0;const c=allCandidates(s,mrc(),now).find(c=>c.supplement)!;expect(beginTask(s,c,now)).toBe(s)})

 it('failed full-test deadline stays fixed across four days of partial practice',()=>{
  let s=finish(tested(platform(),'full'),now+1000,'miss');const id=s.active!.itemId
  for(let day=1;day<=4;day++){
   const at=now+day*DAY+2000;s=lockChapters(rollDay(s,at),mrc(),at)
   const candidate=allCandidates(s,mrc(),at).find(c=>c.itemId===id)!
   expect(candidate.activity).toBe('full')
   s=finish(beginTask(s,{...candidate,activity:'short'},at),at+1000,'pass')
  }
 })
 it('heading mistakes remain eligible in short repair scope',()=>{
  const s=platform(),item=content.items.find(i=>i.coreA&&i.checkPoints.some(p=>p.role==='heading'))!
  s.study!.declarations[key('mrc',item.id)]=now-2*DAY
  const c=allCandidates(s,mrc(),now).find(c=>c.itemId===item.id)!
  let active=finish(beginTask(s,{...c,activity:'full'},now),now+1000,'pass')
  const r=active.study!.records[0],heading=r.scope.find(p=>p.role==='heading')!
  r.outcomes[heading.id]='miss';r.complete=false
  const session=makeSession(active,{...active.active!,id:'repair',activity:'short'})
  expect(session.scope.some(p=>p.id===heading.id)).toBe(true)
 })

 it('six delayed successful short tests after a full pass do not stay at24hours',()=>{
  let s=finish(tested(platform(),'full'),now+1000);let at=now+3*DAY+2000
  const gaps:number[]=[]
  for(let n=0;n<6;n++){
   s=rollDay(s,at);const task={...s.study!.records[0],...s.day.tasks[0],...s.active,id:`stable-${n}`,itemId:s.study!.records[0].itemId,module:'general' as const,subject:'运动生理学',title:'stable',chapterKey:'stable',isNew:false,reason:'test',estimatedMinutes:12,status:'in_progress' as const,activity:'short' as const,startedAt:at}
   s={...s,active:task,day:{...s.day,tasks:[task]},study:{...s.study!,session:makeSession(s,task)}}
   s=finish(s,at+1000);const r=s.study!.records.at(-1)!;gaps.push((r.nextAt-r.finishedAt)/DAY);expect(r.complete).toBe(false);if(n<2)expect(allCandidates(s,mrc(),r.finishedAt+DAY).some(c=>c.itemId===r.itemId)).toBe(false);at=r.nextAt+1000
  }
  expect(gaps.every(d=>d>=3)).toBe(true);expect(gaps.at(-1)).toBeGreaterThan(3)
 })
 it('same-day repair cannot earn delayed spacing',()=>{const s=finish(tested(platform()));expect(shortGapDays(s.study!.records,s.study!.session!,false)).toBe(1)})

 it('repeated narrow samples cannot earn coverage bonuses, and hints reset the streak',()=>{
  const s=finish(tested(platform(),'full'));const original=s.study!.records[0]
  const narrow={...original,activity:'short' as const,scope:original.scope.slice(0,1),allPointIds:Array.from({length:20},(_,i)=>`p-${i}`)}
  const rows=Array.from({length:6},(_,i)=>({...narrow,id:`n-${i}`,taskId:`n-${i}`}))
  expect(shortGapDays(rows,narrow,true)).toBe(3)
  rows[5].hinted=true;expect(shortGapDays(rows,narrow,true)).toBe(2)
 })

})
