import { useMemo, useState } from 'react'
import { content, getItem } from '../content'
import { DataTable, escapeHtml, RedlineCard, RichText, SectionList, Signals } from '../components/render'
import { useOptionalFusion } from '../fusion/store'
import { libraryCandidates } from '../fusion/planner'
import { useApp } from '../state/store'
import type { ReaderMode, Section, StudyItem } from '../types'

export function Library() {
  const app = useApp()
  const lib = app.state.library
  const chapters = content.chapters.filter((chapter) => lib.source === 'all' || chapter.source === lib.source)
  const chapter = chapters.find((row) => row.id === lib.chapterId) || chapters[0]
  const hits = useMemo(() => search(lib.query, lib.source), [lib.query, lib.source])
  const [showAllHits, setShowAllHits] = useState(false)
  const item = lib.itemId ? getItem(lib.itemId) : undefined
  const page = content.pages.find((row) => row.anchor === lib.pageAnchor)
  const note = app.state.notes.find((row) => row.itemId === item?.id)?.text || ''
  return (
    <div className="library">
      <aside>
        <div className="actions">
          {(['A', 'B', 'all'] as const).map((source) => (
            <button key={source} type="button" className={lib.source === source ? 'btn primary' : 'btn'} onClick={() => app.setLibrary({ source, chapterId: '', itemId: '', pageAnchor: '' })}>{source === 'all' ? '全部' : source === 'A' ? '正文' : '附录'}</button>
          ))}
        </div>
        <input aria-label="搜索管理学原文" value={lib.query} placeholder="搜索正文或附录原文" onChange={(event) => { setShowAllHits(false); app.setLibrary({ query: event.target.value, itemId: '', pageAnchor: '' }) }} />
        <details className="bookmarks"><summary>我的书签（{app.state.bookmarks.length}）</summary>
          {!app.state.bookmarks.length && <p className="muted">在题目或原文页添加书签后，可从这里返回。</p>}
          <ul className="plain">{app.state.bookmarks.map(id => {
            const markedItem = getItem(id)
            const markedPage = content.pages.find(row => row.anchor === id)
            return <li key={id}>{markedItem || markedPage ? <button className="linkish" type="button" onClick={() => app.setLibrary(markedItem
              ? { source: markedItem.source, chapterId: markedItem.chapterId, itemId: id, pageAnchor: '', query: '' }
              : { source: markedPage!.source, chapterId: '', itemId: '', pageAnchor: id, query: '' })}>{markedItem?.title || (markedPage!.page === 0 ? '使用说明' : `${markedPage!.source === 'A' ? '正文' : '附录'} 第 ${markedPage!.page} 题`)}</button>
              : <span>原资料已不在当前版本中</span>}
              <button className="btn ghost" type="button" aria-label={`移除书签：${markedItem?.title || markedPage?.anchor || id}`} onClick={() => app.toggleBookmark(id)}>移除</button></li>
          })}</ul>
        </details>
        <label className="mobile-chapter field">选择章节<select aria-label="管理学章节" value={chapter?.id || ''} onChange={e => app.setLibrary({ chapterId: e.target.value, itemId: '', pageAnchor: '', query: '' })}>{chapters.map(row => <option key={row.id} value={row.id}>{row.title}</option>)}</select></label>
        <ul className="toc">
          {chapters.map((row) => (
            <li key={row.id}>
              <button type="button" className={chapter?.id === row.id ? 'on' : ''} onClick={() => app.setLibrary({ chapterId: row.id, itemId: '', pageAnchor: '' })}>{row.title}</button>
            </li>
          ))}
        </ul>
      </aside>
      <div className="stack">
        {lib.query.trim() ? (
          <section className="card">
            <h2>{lib.source === 'all' ? '全部资料' : lib.source === 'A' ? '正文' : '附录'}搜索：{hits.length} 条原文</h2>
            {!hits.length && <p className="muted">当前范围没有匹配内容。可缩短关键词，或切换到“全部”搜索。</p>}
            {hits.length > 40 && <p className="muted">{showAllHits ? `显示全部 ${hits.length} 条` : `显示前 40 条，共 ${hits.length} 条`}</p>}
            <ul className="plain">
              {(showAllHits ? hits : hits.slice(0, 40)).map((hit) => (
                <li key={hit.anchor + hit.title}>
                  <button type="button" className="linkish" onClick={() => { const found = getItem(hit.anchor); app.setLibrary(found ? { source: found.source, chapterId: found.chapterId, itemId: found.id, pageAnchor: '', query: '' } : { pageAnchor: hit.anchor, chapterId: '', itemId: '', query: '' }) }}>{hit.source === 'A' ? '正文' : '附录'} 第 {hit.page} 题 · {hit.title}</button>
                  <small dangerouslySetInnerHTML={{ __html: hit.snippet }} />
                </li>
              ))}
            </ul>
            {hits.length > 40 && !showAllHits && <button className="btn" onClick={() => setShowAllHits(true)}>显示全部搜索结果</button>}
          </section>
        ) : null}
        {page ? <PageView anchor={page.anchor} markdown={page.markdown} page={page.page} source={page.source} /> : null}
        {!page && item ? <ItemView key={item.id} item={item} mode={lib.mode} note={note} /> : null}
        {!page && !item && chapter ? <ChapterView chapterId={chapter.id} /> : null}
      </div>
    </div>
  )
}

function ChapterView({ chapterId }: { chapterId: string }) {
  const app = useApp()
  const fusion = useOptionalFusion()
  const trainable = fusion ? libraryCandidates(fusion.state, app.state, app.now).filter(c => c.module === 'mrc' && c.chapterKey === `mrc::${chapterId}`) : []
  const chapter = content.chapters.find((row) => row.id === chapterId)
  if (!chapter) return null
  const items = content.items.filter((item) => item.chapterId === chapter.id)
  const index = content.chapters.filter((row) => row.source === chapter.source).findIndex((row) => row.id === chapter.id)
  const siblings = content.chapters.filter((row) => row.source === chapter.source)
  return (
    <article className="stack">
      <header className="page-head">
        <div>
          <p className="kicker">{chapter.source === 'A' ? '正文' : '附录'}</p>
          <h1>{chapter.title}</h1>
        </div>
        <div className="actions">
          {fusion && trainable.length > 0 && <button className="btn primary" disabled={fusion.blocked} onClick={() => fusion.requestPractice({ module: 'mrc', kind: 'chapter', title: chapter.title, itemIds: trainable.map(c => c.itemId) })}>练习本节</button>}
          <button className="btn" type="button" disabled={index <= 0} onClick={() => app.setLibrary({ chapterId: siblings[index - 1].id })}>上一章</button>
          <button className="btn" type="button" disabled={index >= siblings.length - 1} onClick={() => app.setLibrary({ chapterId: siblings[index + 1].id })}>下一章</button>
        </div>
      </header>
      {chapter.title.includes('文件说明') || chapter.title.includes('目录') || chapter.title.includes('封面') ? <Conflict /> : null}
      {chapter.intro ? <RichText text={chapter.intro} /> : null}
      {chapter.flow.map((block, i) => {
        if (block.type === 'prose') return <RichText key={i} text={block.text || ''} />
        if (block.type === 'table') {
          return (
            <div key={i}>
              <DataTable table={{ headers: block.headers || [], rows: block.rows || [], role: block.role }} />
              {block.role === 'redline' ? <p className="muted">红线表保持「别写 / 要写 / 依据」三列。</p> : null}
            </div>
          )
        }
        const row = block.itemId ? getItem(block.itemId) : undefined
        if (!row) return null
        return (
          <button key={row.id} className="linkish block-link" type="button" onClick={() => app.setLibrary({ itemId: row.id })}>
            {row.kind === 'full_answer' ? '完整题' : row.kind === 'redline' ? '红线' : row.fullTextForLookup ? 'B级专题' : row.kind === 'skeleton' ? '骨架' : row.kind === 'comparison' ? '对照表' : '参考资料'} · {row.title}
          </button>
        )
      })}
      {items.length && chapter.flow.every((block) => block.type !== 'item') ? (
        <ul className="plain">
          {items.map((row) => <li key={row.id}><button className="linkish" type="button" onClick={() => app.setLibrary({ itemId: row.id })}>{row.title}</button></li>)}
        </ul>
      ) : null}
    </article>
  )
}

function ItemView({ item, mode, note }: { item: StudyItem; mode: ReaderMode; note: string }) {
  const app = useApp()
  const fusion = useOptionalFusion()
  const canTrain = fusion ? libraryCandidates(fusion.state, app.state, app.now).some(c => c.module === 'mrc' && c.itemId === item.id) : item.kind !== 'reference'
  const ids = content.items.filter((row) => row.chapterId === item.chapterId && row.kind === item.kind)
  const index = ids.findIndex((row) => row.id === item.id)
  const sections = filterSections(item, mode)
  return (
    <article className="stack">
      <header className="page-head">
        <div>
          <p className="kicker">{item.chapter} · 管理学 ultimate</p>
          <h1>{item.title}</h1>
          {item.fullTextForLookup ? <p className="badge">B级骨架 · 全文供查阅 · 不因篇幅提高优先级</p> : null}
          <Signals item={item} />
        </div>
        <div className="actions">
          <button className="btn ghost" type="button" onClick={() => app.setLibrary({ source: item.source, chapterId: item.chapterId, itemId: '', pageAnchor: '', query: '' })}>返回本章目录</button>
          <button className="btn" type="button" onClick={() => app.toggleBookmark(item.id)}>{app.state.bookmarks.includes(item.id) ? '已加书签' : '加书签'}</button>
          {canTrain && <button className="btn primary" type="button" disabled={fusion?.blocked} onClick={() => app.startRecallItem(item.id)}>{fusion ? '练这道题' : '提取这题'}</button>}
        </div>
      </header>
      {item.source === 'A' && item.kind === 'full_answer' ? (
        <div className="actions">
          {([['skeleton', '只看骨架'], ['no-expansion', '隐藏扩展'], ['short', '简答主体'], ['all', '全部显示']] as const).map(([key, label]) => (
            <button key={key} type="button" className={mode === key ? 'btn primary' : 'btn'} onClick={() => app.setLibrary({ mode: key })}>{label}</button>
          ))}
        </div>
      ) : null}
      <div className="actions">
        {item.pdfPages.map((page) => (
          <button key={page} className="btn ghost" type="button" onClick={() => app.setLibrary({ pageAnchor: `${item.source.toLowerCase()}-pdf-page-${page}`, itemId: '' })}>PDF 第 {page} 页</button>
        ))}
      </div>
      {item.kind === 'redline' ? <RedlineCard item={item} /> : null}
      {item.kind === 'comparison' ? item.tables.map((table, i) => <DataTable key={i} table={table} />) : null}
      {item.fullTextForLookup ? (
        <>
          <ol>{item.reviewedHeadingHints.map((hint) => <li key={hint}>{hint}</li>)}</ol>
          <details>
            <summary>全文供查阅，默认折叠</summary>
            <SectionList sections={item.sections} />
          </details>
        </>
      ) : item.kind !== 'redline' ? <SectionList sections={sections} /> : null}
      {item.kind !== 'comparison' && item.kind !== 'redline' ? item.tables.map((table, i) => <DataTable key={`t-${i}`} table={table} />) : null}
      <p className="muted">本章同类题：第 {index + 1} / {ids.length} 题</p>
      <div className="actions">
        <button className="btn" type="button" disabled={index <= 0} onClick={() => app.setLibrary({ itemId: ids[index - 1].id })}>上一题</button>
        <button className="btn" type="button" disabled={index >= ids.length - 1} onClick={() => app.setLibrary({ itemId: ids[index + 1].id })}>下一题</button>
      </div>
      <label className="field">我的批注（不写回原文）
        <textarea rows={4} value={note} onChange={(event) => app.saveNote(item.id, event.target.value)} />
      </label>
      <p className="muted">批注随输入自动保存，切换题目后仍保留；保存失败时页面顶部会提示。</p>
    </article>
  )
}

function PageView({ anchor, markdown, page, source }: { anchor: string; markdown: string; page: number; source: string }) {
  const app = useApp()
  return (
    <article className="card stack">
      <header className="page-head">
        <h1>{source === 'A' ? '正文' : '附录'} · {page === 0 ? '使用说明' : `第 ${page} 题`}</h1>
        <button className="btn" type="button" onClick={() => app.toggleBookmark(anchor)}>{app.state.bookmarks.includes(anchor) ? '已加书签' : '给这页加书签'}</button>
      </header>
      <RichText text={markdown.replace(/^(#{1,6}) /gm, '').replace(/(\d+)\\\.[ \t]*\n?/g, '$1. ')} query={app.state.library.query} />
      <button className="btn ghost" type="button" onClick={() => app.setLibrary({ pageAnchor: '' })}>返回目录</button>
    </article>
  )
}

function Conflict() {
  return (
    <aside className="card warnbox">
      <h2>资料说明 / 版本差异</h2>
      <p>正文：{content.versionConflict.aStatement}</p>
      <p>附录：{content.versionConflict.bStatement}</p>
      <p>{content.versionConflict.resolution}</p>
      <p className="muted">正文按原稿小标题与段落核对；附录仅供查询，不自动派题。旧记录可在设置中的管理学学习档案查看。</p>
    </aside>
  )
}

function filterSections(item: StudyItem, mode: ReaderMode): Section[] {
  if (mode === 'skeleton') {
    return item.reviewedHeadingHints.map((title, index) => ({ id: `${item.id}-sk-${index}`, title, sourceText: '', layer: 'normal' as const }))
  }
  if (mode === 'no-expansion') return item.sections.filter((section) => section.layer !== 'expansion')
  if (mode === 'short') return item.sections.filter((section) => section.layer === 'definition' || section.layer === 'short_answer')
  return item.sections
}

function search(query: string, source: 'A' | 'B' | 'all') {
  const q = query.trim()
  if (!q) return []
  const hits = []
  for (const page of content.pages) {
    if (source !== 'all' && page.source !== source) continue
    const at = page.markdown.indexOf(q)
    if (at < 0) continue
    const slice = page.markdown.slice(Math.max(0, at - 24), at + q.length + 36).replace(/\s+/g, ' ')
    hits.push({
      source: page.source,
      page: page.page,
      anchor: page.anchor,
      title: slice,
      snippet: escapeHtml(slice).split(escapeHtml(q)).join(`<mark>${escapeHtml(q)}</mark>`),
    })
  }
  return hits
}
