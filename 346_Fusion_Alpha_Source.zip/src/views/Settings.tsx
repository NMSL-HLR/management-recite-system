import { MigrationReview } from '../components/MigrationReview'
import { useOptionalFusion } from '../fusion/store'
import { useEffect, useState } from 'react'
import { content, getItem } from '../content'
import { useApp } from '../state/store'
import { UI_VERSION } from '../state/uiSettings'
import type { ReadingScale, RelationStatus } from '../types'

export function Settings() {
  const app = useApp()
  const fusion = useOptionalFusion()
  const [allRelations, setAllRelations] = useState(false)
  const settings = app.state.settings
  const [keywordQuery, setKeywordQuery] = useState('')
  const [customItem, setCustomItem] = useState(content.items.find((item) => item.coreA)?.id || '')
  const [customText, setCustomText] = useState('')
  const [customError, setCustomError] = useState<string | null>(null)
  const [fileError, setFileError] = useState('')
  const keywords = content.keywords.flatMap((bucket) => bucket.hints.map((hint) => ({ ...hint, itemId: bucket.itemId })))
    .filter((hint) => !keywordQuery.trim() || hint.text.includes(keywordQuery.trim()) || (getItem(hint.itemId)?.title || '').includes(keywordQuery.trim()))
    .slice(0, 40)
  return (
    <div className="stack">
      <h1>设置与数据</h1>
      {!fusion && <section className="card">
        <h2>方法与原版工具</h2>
        <p className="muted">每日任务从今日训练开始。以下保留 V2.2.2 的方法说明与工具。</p>
        <div className="actions">
          <button className="btn" type="button" onClick={() => app.setView('method')}>方法论</button>
          <button className="btn" type="button" onClick={() => app.setView('exam')}>闭卷考试（原版）</button>
          <button className="btn" type="button" onClick={() => app.setView('mistakes')}>错漏记录</button>
        </div>
      </section>}
      <section className="card">
        <h2>版本</h2>
        <p>schemaVersion {content.meta.schemaVersion}</p>
        <p>contentVersion {content.meta.contentVersion}</p>
        <p>uiVersion {UI_VERSION}</p>
        <p className="mono">A {content.meta.sourceHashes.A}</p>
        <p className="mono">B {content.meta.sourceHashes.B}</p>
        <p className="muted">构建于 {content.meta.builtAt}。hash 变化表示源 Markdown 变了，旧记录按 itemId 迁移，对不上的进待查。</p>
      </section>
      {!fusion && <section className="card">
        <h2>导入导出</h2>
        <div className="actions">
          <button className="btn primary" type="button" onClick={app.exportJson}>导出 JSON</button>
          <button className="btn" type="button" onClick={app.rollback}>恢复到导入前备份</button>
        </div>
        <label className="field">选择 JSON
          <input type="file" accept="application/json" onChange={async (event) => {
            const file = event.target.files?.[0]
            event.target.value = ''
            if (!file) return
            setFileError('')
            try { app.stageImport(await file.text()) } catch { setFileError('文件读取失败，当前记录未改动。请重新选择文件。') }
          }} />
        </label>
        {fileError && <p className="warnbox" role="alert">{fileError}</p>}
        {app.importPlan ? (
          <div className="warnbox">
            <p>{app.importPlan.summary.message}</p>
            <p>新增 {app.importPlan.summary.added}，覆盖 {app.importPlan.summary.replaced}，对不上 {app.importPlan.summary.unmatched}。</p>
            <p>文件 schema {app.importPlan.summary.schemaVersion}，内容版本 {app.importPlan.summary.contentVersion}。{app.importPlan.summary.crossSchema ? '结构版本较旧，已按当前程序读取。' : ''}</p>
            <div className="actions">
              <button className="btn primary" type="button" onClick={app.confirmImport}>确认写入</button>
              <button className="btn ghost" type="button" onClick={app.cancelImport}>取消</button>
            </div>
          </div>
        ) : <p className="muted">坏文件会停在预览之前。确认后才写入，写入前自动备份。</p>}
      </section>}
      {fusion && <section className="card"><h2>备份与外观</h2><p>整包备份、明暗外观和每日预算统一在全科设置中调整；字号和专注阅读使用顶部阅读栏。</p><button className="btn" onClick={() => fusion.open('settings')}>前往全科设置</button></section>}
      <MigrationReview />
      {!fusion && <section className="card">
        <h2>阅读显示</h2>
        <div className="actions">
          <button className="btn" type="button" onClick={() => app.updateSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' })}>{settings.theme === 'dark' ? '浅色' : '深色'}</button>
          {(['compact', 'standard', 'recite'] as ReadingScale[]).map((scale) => (
            <button
              key={scale}
              className={settings.readingScale === scale ? 'btn primary' : 'btn'}
              type="button"
              onClick={() => app.updateSettings({ readingScale: scale })}
            >
              {scale === 'compact' ? '紧凑' : scale === 'standard' ? '标准' : '诵读'}
            </button>
          ))}
          <button
            className={settings.focusReading ? 'btn primary' : 'btn'}
            type="button"
            onClick={() => app.updateSettings({ focusReading: !settings.focusReading })}
          >
            沉浸诵读 {settings.focusReading ? '开' : '关'}
          </button>
        </div>
        <p className="muted">快捷键：Alt+1–4 切换主要页面，Alt+Shift+D 切换深浅色。页面顶部阅读栏可切换字号与专注阅读；浏览器占用快捷键时，请使用页面按钮。</p>
      </section>}
      <section className="card">
        <h2>管理学训练选项</h2>
        <p className="muted">以下为原版日程参数。每日训练预算在今日作战台调整；原版闭卷计时与复测间隔继续使用原设置。</p>
        <NumberField label="限时写作默认分钟" value={settings.day.writingMinutes} min={1} onChange={(writingMinutes) => app.updateSettings({ day: { ...settings.day, writingMinutes } })} />
        <label className="check"><input type="checkbox" checked={settings.day.includeAppendix2} onChange={(event) => app.updateSettings({ day: { ...settings.day, includeAppendix2: event.target.checked } })} />包含附录两道完整题</label>
        <details><summary>原版日程参数（当前全科教练不使用）</summary><p className="muted">仅保留旧版兼容值，不会改变全科每日预算、配额或休息安排。</p><div className="form-grid">
          <NumberField label="总分钟" value={settings.day.totalMinutes} onChange={(totalMinutes) => app.updateSettings({ day: { ...settings.day, totalMinutes } })} />
          <NumberField label="晚测分钟" value={settings.day.eveningMinutes} onChange={(eveningMinutes) => app.updateSettings({ day: { ...settings.day, eveningMinutes } })} />
          <NumberField label="B 级最多分钟" value={settings.day.bOnlyMaxMinutes} onChange={(bOnlyMaxMinutes) => app.updateSettings({ day: { ...settings.day, bOnlyMaxMinutes } })} />
          <NumberField label="休息间隔" value={settings.day.restEvery} onChange={(restEvery) => app.updateSettings({ day: { ...settings.day, restEvery } })} />
          <NumberField label="休息分钟" value={settings.day.restMinutes} onChange={(restMinutes) => app.updateSettings({ day: { ...settings.day, restMinutes } })} />
        </div>
        <label className="check"><input type="checkbox" checked={settings.day.protectEvening} onChange={(event) => app.updateSettings({ day: { ...settings.day, protectEvening: event.target.checked } })} />保留晚间闭卷</label>
        <label className="check"><input type="checkbox" checked={settings.day.prioritizeA26} onChange={(event) => app.updateSettings({ day: { ...settings.day, prioritizeA26: event.target.checked } })} />优先排 A 册 26 题</label>
        </details>
        <label className="check"><input type="checkbox" checked={settings.showTimer} onChange={(event) => app.updateSettings({ showTimer: event.target.checked })} />显示计时</label>
      </section>
      <section className="card">
        <h2>间隔（分钟 / 小时 / 天）</h2>
        <div className="form-grid">
          <NumberField min={0.01} label="重学分钟" value={settings.gaps.relearnedMin} onChange={(relearnedMin) => app.updateSettings({ gaps: { ...settings.gaps, relearnedMin } })} />
          <NumberField min={0.01} label="提示依赖分钟" value={settings.gaps.cueMin} onChange={(cueMin) => app.updateSettings({ gaps: { ...settings.gaps, cueMin } })} />
          <NumberField min={0.01} label="少量遗漏小时" value={settings.gaps.minorHours} onChange={(minorHours) => app.updateSettings({ gaps: { ...settings.gaps, minorHours } })} />
          <NumberField min={0.01} label="独立后天数" value={settings.gaps.independentDays} onChange={(independentDays) => app.updateSettings({ gaps: { ...settings.gaps, independentDays } })} />
          <NumberField min={0.01} label="再次独立后天数" value={settings.gaps.independentAgainDays} onChange={(independentAgainDays) => app.updateSettings({ gaps: { ...settings.gaps, independentAgainDays } })} />
        </div>
      </section>
      <section className="card">
<h2>A/B 关系审核</h2><label className="check"><input type="checkbox" checked={allRelations} onChange={e => setAllRelations(e.target.checked)} />显示全部关系（默认只看待审核候选）</label>
        <p className="muted">候选不会进入提示链。确认只存在这份学习记录里，不改原文。</p>
        <ul className="review">
          {content.relations.filter(rel => allRelations || (app.state.relationOverrides[rel.id] || rel.status) === 'candidate').map((rel) => {
            const status = app.state.relationOverrides[rel.id] || rel.status
            const a = getItem(rel.aItemId)
            const b = getItem(rel.bItemId)
            return (
              <li key={rel.id}>
                <p><b>{status}</b> · {rel.role}</p>
                <p>{a?.title}</p>
                <p>{b?.title}</p>
                <p className="muted">{rel.reason}</p>
                <StatusButtons current={status} onChange={(next) => app.setRelation(rel.id, next)} />
              </li>
            )
          })}
        </ul>
      </section>
      <section className="card">
        <h2>关键词审核</h2>
        <input value={keywordQuery} placeholder="筛原词或题干" onChange={(event) => setKeywordQuery(event.target.value)} />
        <ul className="review">
          {keywords.map((hint) => {
            const status = app.state.keywordOverrides[hint.id] || hint.status
            return (
              <li key={hint.id}>
                <p>「{hint.text}」 · {status}</p>
                <p className="muted">{getItem(hint.itemId)?.title} · {hint.evidence}</p>
                <StatusButtons current={status} onChange={(next) => app.setKeyword(hint.id, next)} />
              </li>
            )
          })}
        </ul>
        <div className="form-grid">
          <label className="field">题目
            <select value={customItem} onChange={(event) => setCustomItem(event.target.value)}>
              {content.items.filter((item) => item.coreA || item.kind === 'skeleton').slice(0, 80).map((item) => <option key={item.id} value={item.id}>{item.title.slice(0, 28)}</option>)}
            </select>
          </label>
          <label className="field">必须是原文里的连续片段
            <input value={customText} onChange={(event) => setCustomText(event.target.value)} />
          </label>
        </div>
        <button className="btn" type="button" onClick={() => setCustomError(app.addCustomKeyword(customItem, customText) ?? '已加入；下次训练这题时可作为关键词提示。')}>加入自定义关键词</button>
        {customError ? <p>{customError}</p> : null}
      </section>
    </div>
  )
}

function StatusButtons({ current, onChange }: { current: RelationStatus; onChange: (status: RelationStatus) => void }) {
  return (
    <div className="actions">
      <button type="button" className={current === 'confirmed' || current === 'confirmed-by-source' ? 'btn primary' : 'btn'} onClick={() => onChange('confirmed')}>确认</button>
      <button type="button" className={current === 'candidate' ? 'btn primary' : 'btn'} onClick={() => onChange('candidate')}>候选</button>
      <button type="button" className={current === 'rejected' ? 'btn primary' : 'btn'} onClick={() => onChange('rejected')}>不用</button>
    </div>
  )
}

function NumberField({ label, value, onChange, min = 0 }: { label: string; value: number; onChange: (value: number) => void; min?: number }) {
  const [draft, setDraft] = useState(String(value))
  const [error, setError] = useState('')
  useEffect(() => { setDraft(String(value)) }, [value])
  const commit = () => {
    const next = Number(draft)
    if (!draft.trim() || !Number.isFinite(next) || next < min) { setError(`请输入不小于 ${min} 的数字，原设置未改动。`); return }
    setError(''); if (next !== value) onChange(next)
  }
  return (
    <label className="field">{label}
      <input type="number" min={min} step="any" value={draft} aria-invalid={Boolean(error)} onChange={event => { setDraft(event.target.value); setError('') }} onBlur={commit} onKeyDown={e => { if (e.key === 'Enter') e.currentTarget.blur(); if (e.key === 'Escape') { setDraft(String(value)); setError('') } }} />
      {error && <small role="status">{error}</small>}
    </label>
  )
}
